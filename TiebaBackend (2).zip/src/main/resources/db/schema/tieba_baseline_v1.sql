-- TiebaBackend MySQL baseline schema v1
-- Compatible with current MyBatis mapper SQL.
-- Execute manually in your target database (for example: tieba).

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` varchar(64) NOT NULL COMMENT 'AES加密学号',
  `password` varchar(64) NOT NULL COMMENT 'BCrypt加密密码',
  `nickname` varchar(50) DEFAULT '用户' COMMENT '昵称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_id` (`student_id`),
  UNIQUE KEY `uk_nickname` (`nickname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `publish_content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `like_count` int DEFAULT '0',
  `collect_count` int DEFAULT '0',
  `comment_count` int DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `publish_id` int NOT NULL,
  `user_id` int NOT NULL,
  `content` text NOT NULL,
  `score` decimal(3,1) DEFAULT NULL COMMENT '星级',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_comment_publish` (`publish_id`),
  KEY `fk_comment_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `user_collect` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `publish_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_collect` (`user_id`, `publish_id`),
  KEY `fk_collect_publish` (`publish_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `user_like` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `publish_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_like` (`user_id`, `publish_id`),
  KEY `fk_like_publish` (`publish_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

