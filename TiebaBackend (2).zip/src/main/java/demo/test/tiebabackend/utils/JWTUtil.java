package demo.test.tiebabackend.utils;
import demo.test.tiebabackend.entity.User;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
public class JWTUtil {
    private static final String SECRET = "12345678901234567890123456789012";
    private static final SecretKey KEY = Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));
    private static final long EXPIRE = 1000 * 60 * 60 * 24;

    public static String createToken(User user) {
        return Jwts.builder()
                .setSubject(user.getId().toString())
                .claim("studentId", user.getStudentId())
                .claim("nickname", user.getNickname())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRE))
                .signWith(KEY)
                .compact();
    }

    public static Integer getUserId(String token) {
        String id = Jwts.parser()
                .setSigningKey(KEY)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
        return Integer.parseInt(id);
    }
}