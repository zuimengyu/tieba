package demo.test.tiebabackend.utils;

public interface RedisOps {
    // 设置值
    void set(String key, Object value);

    // 设置值并指定过期时间
    void set(String key, Object value, long time);

    // 获取值
    Object get(String key);

    // 删除键
    void delete(String key);
}

