package demo.test.tiebabackend.service.impl;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.mapper.PublishMapper;
import demo.test.tiebabackend.service.PublishService;
import demo.test.tiebabackend.utils.RedisOps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import jakarta.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class PublishServiceImpl implements PublishService {

    private static final String PUBLISH_ALL_KEY = "publish:all";
    private static final long PUBLISH_CACHE_TTL_MINUTES = 30;
    private static final Logger log = LoggerFactory.getLogger(PublishServiceImpl.class);

    @Resource
    private PublishMapper publishMapper;
    @Resource
    private RedisOps redisUtil;

    /**
     * 查询帖子列表。
     * 优先从 Redis 读取；未命中时查询数据库并写入缓存。
     * 返回前会叠加未落库的增量计数。
     *
     * @return 帖子列表
     */
    @Override
    @Transactional(readOnly = true)
    @SuppressWarnings("unchecked")
    public Result<List<PublishContent>> getAllPublish() {
        Object cacheObj = redisUtil.get(PUBLISH_ALL_KEY);
        if (cacheObj != null) {
            List<PublishContent> cacheList = (List<PublishContent>) cacheObj;
            return Result.success(cacheList);
        }

        List<PublishContent> list = publishMapper.selectAll();
        redisUtil.set(PUBLISH_ALL_KEY, list, PUBLISH_CACHE_TTL_MINUTES);
        return Result.success(list);
    }

    /**
     * 发布帖子（事务）。
     * 先落库，再清理列表缓存，保证后续读取能看到新帖。
     *
     * @param userId 发布者 ID
     * @param title 标题
     * @param content 内容
     * @return 发布结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<String> addPublish(Integer userId, String title, String content) {
        PublishContent p = new PublishContent();
        p.setUserId(userId);
        p.setTitle(title);
        p.setContent(content);
        p.setCreateTime(new Date());
        publishMapper.insertPublish(p);

        // New publish affects list ordering/counts, so clear list cache.
        // 在事务提交后再清理缓存，避免事务回滚后缓存被错误删除
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                try {
                    redisUtil.delete(PUBLISH_ALL_KEY);
                } catch (Exception e) {
                    log.error("[afterCommit] clear publish list cache failed msg={}", e.getMessage(), e);
                }
            }
        });
        return Result.success("发布成功");
    }

    /**
     * 查询帖子详情。
     * 优先读取详情缓存；未命中则回源数据库并缓存。
     * 返回前会叠加未同步到数据库的计数增量。
     *
     * @param id 帖子 ID
     * @return 帖子详情
     */
    @Override
    @Transactional(readOnly = true)
    public Result<PublishContent> getPublishById(Integer id) {
        String detailKey = "publish:detail:" + id;
        Object cacheObj = redisUtil.get(detailKey);
        if (cacheObj != null) {
            PublishContent cachePublish = (PublishContent) cacheObj;
            return Result.success(cachePublish);
        }

        PublishContent publish = publishMapper.selectById(id);
        if (publish == null) {
            return Result.error("帖子不存在");
        }

        redisUtil.set(detailKey, publish, PUBLISH_CACHE_TTL_MINUTES);
        return Result.success(publish);
    }

    /**
     * 查询我的发布列表。
     *
     * @param userId 用户 ID
     * @return 发布列表
     */
    @Override
    @Transactional(readOnly = true)
    public Result<List<PublishContent>> myPublish(Integer userId) {
        List<PublishContent> list = publishMapper.myPublish(userId);
        return Result.success(list);
    }
}

