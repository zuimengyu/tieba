package demo.test.tiebabackend.service;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;
import java.util.List;

public interface PublishService {
    // 查询所有帖子
    Result<List<PublishContent>> getAllPublish();

    // 发布帖子
    Result<String> addPublish(Integer userId, String title, String content);

    // 根据ID查询帖子详情
    Result<PublishContent> getPublishById(Integer id);

    // 查询我的发布列表
    Result<List<PublishContent>> myPublish(Integer userId);
}