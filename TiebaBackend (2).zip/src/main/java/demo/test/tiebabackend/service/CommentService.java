package demo.test.tiebabackend.service;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.Comment;
import java.util.List;

public interface CommentService {
    // 根据帖子ID查询评论列表
    Result<List<Comment>> getByPublishId(Integer publishId);

    // 发布评论
    Result<String> addComment(Integer userId, Integer publishId, String content, Double score);
}