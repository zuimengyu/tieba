package demo.test.tiebabackend.service;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;

import java.util.List;

public interface UserLikeService {
    // 点赞或取消点赞
    Result<String> like(Integer userId, Integer publishId);

    // 查询我的点赞列表
    Result<List<PublishContent>> myLike(Integer userId);

    // 查询当前用户是否点赞当前帖子
    Result<Boolean> liked(Integer userId, Integer publishId);
}

