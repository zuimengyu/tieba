package demo.test.tiebabackend.service.impl;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.mapper.PublishMapper;
import demo.test.tiebabackend.entity.UserLike;
import demo.test.tiebabackend.mapper.UserLikeMapper;
import demo.test.tiebabackend.service.UserLikeService;
import demo.test.tiebabackend.utils.RedisOps;
import jakarta.annotation.Resource;
import org.springframework.dao.DuplicateKeyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.List;

@Service
public class UserLikeServiceImpl implements UserLikeService {

    private static final String PUBLISH_ALL_KEY = "publish:all";

    @Resource
    private UserLikeMapper userLikeMapper;
    @Resource
    private PublishMapper publishMapper;
    @Resource
    private RedisOps redisUtil;
    private static final Logger log = LoggerFactory.getLogger(UserLikeServiceImpl.class);

    // 点赞或取消点赞
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<String> like(Integer userId, Integer publishId) {
        // 先校验帖子是否存在，避免向不存在的帖子插入 like
        PublishContent existing = publishMapper.selectById(publishId);
        if (existing == null) {
            return Result.error("帖子不存在");
        }

        UserLike like = userLikeMapper.selectByUserAndPublish(userId, publishId);
        if (like != null) {
            userLikeMapper.deleteLike(userId, publishId);
            int rows = publishMapper.subLikeCount(publishId);
            if (rows == 0) {
                // 如果减失败，抛异常回滚删除操作
                throw new RuntimeException("取消点赞失败：帖子不存在或计数已为0");
            }

            // 事务提交后再清理缓存
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    try {
                        invalidatePublishDetailCache(publishId);
                        invalidatePublishListCache();
                    } catch (Exception e) {
                        log.error("[afterCommit] clear like caches failed publishId={} msg={}", publishId, e.getMessage(), e);
                    }
                }
            });

            return Result.success("取消点赞");
        }

        UserLike l = new UserLike();
        l.setUserId(userId);
        l.setPublishId(publishId);
        try {
            userLikeMapper.insertLike(l);
        } catch (DuplicateKeyException ex) {
            // 并发情况下可能重复插入，视为已点赞
            log.info("duplicate like ignored userId={} publishId={}", userId, publishId);
            return Result.success("已点赞");
        }

        int rows = publishMapper.addLikeCount(publishId);
        if (rows == 0) {
            // 如果计数更新失败，抛异常回滚 insert
            throw new RuntimeException("点赞失败：帖子不存在或计数更新失败");
        }

        // 事务提交后再清理缓存
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                try {
                    invalidatePublishDetailCache(publishId);
                    invalidatePublishListCache();
                } catch (Exception e) {
                    log.error("[afterCommit] clear like caches failed publishId={} msg={}", publishId, e.getMessage(), e);
                }
            }
        });
        return Result.success("点赞成功");
    }

    // 查询我的点赞列表
    @Override
    @Transactional(readOnly = true)
    public Result<List<PublishContent>> myLike(Integer userId) {
        List<PublishContent> list = userLikeMapper.myLike(userId);
        return Result.success(list);
    }

    // 查询当前用户是否点赞当前帖子
    @Override
    @Transactional(readOnly = true)
    public Result<Boolean> liked(Integer userId, Integer publishId) {
        UserLike like = userLikeMapper.selectByUserAndPublish(userId, publishId);
        return Result.success(like != null);
    }

    private void invalidatePublishDetailCache(Integer publishId) {
        redisUtil.delete(buildPublishDetailKey(publishId));
    }

    private void invalidatePublishListCache() {
        redisUtil.delete(PUBLISH_ALL_KEY);
    }

    private String buildPublishDetailKey(Integer publishId) {
        return "publish:detail:" + publishId;
    }
}
