package demo.test.tiebabackend.service.impl;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.Comment;
import demo.test.tiebabackend.mapper.CommentMapper;
import demo.test.tiebabackend.mapper.PublishMapper;
import demo.test.tiebabackend.service.CommentService;
import demo.test.tiebabackend.utils.RedisOps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import jakarta.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {

    private static final String PUBLISH_ALL_KEY = "publish:all";
    private static final long COMMENT_CACHE_TTL_MINUTES = 10;
    private static final Logger log = LoggerFactory.getLogger(CommentServiceImpl.class);

    @Resource
    private CommentMapper commentMapper;
    @Resource
    private PublishMapper publishMapper;
    @Resource
    private RedisOps redisUtil;

    @Override
    @Transactional(readOnly = true)
    public Result<List<Comment>> getByPublishId(Integer publishId) {
        String commentKey = buildCommentListKey(publishId);
        Object cacheObj = redisUtil.get(commentKey);
        if (cacheObj != null) {
            List<Comment> cacheList = (List<Comment>) cacheObj;
            return Result.success(cacheList);
        }

        List<Comment> list = commentMapper.selectByPublishId(publishId);
        redisUtil.set(commentKey, list, COMMENT_CACHE_TTL_MINUTES);
        return Result.success(list);
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<String> addComment(Integer userId, Integer publishId, String content, Double score) {
        Comment comment = new Comment();
        comment.setUserId(userId);
        comment.setPublishId(publishId);
        comment.setContent(content);
        comment.setScore(score);
        comment.setCreateTime(new Date());
        commentMapper.insertComment(comment);

        // Persist first, then clear read caches affected by comment count and list.
        publishMapper.addCommentCount(publishId);

        // 在事务提交后再清理缓存，避免事务回滚后缓存与数据库不一致
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                try {
                    redisUtil.delete(buildCommentListKey(publishId));
                    redisUtil.delete(PUBLISH_ALL_KEY);
                    redisUtil.delete(buildPublishDetailKey(publishId));
                } catch (Exception e) {
                    log.error("[afterCommit] clear comment caches failed publishId={} msg={}", publishId, e.getMessage(), e);
                    // TODO: 可将失败信息推入重试队列或持久化以便后续补偿
                }
            }
        });
        return Result.success("评论成功");
    }

    private String buildCommentListKey(Integer publishId) {
        return "comment:list:" + publishId;
    }

    private String buildPublishDetailKey(Integer publishId) {
        return "publish:detail:" + publishId;
    }
}