package demo.test.tiebabackend.service.impl;

import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.service.RedisSyncServiceApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RedisSyncService implements RedisSyncServiceApi {

    private static final Logger log = LoggerFactory.getLogger(RedisSyncService.class);

    @Override
    public void recordLikeDelta(Integer publishId, int delta) {
        log.info("[RedisSync] disabled, ignore like delta publishId={} delta={}", publishId, delta);
    }

    @Override
    public void recordCollectDelta(Integer publishId, int delta) {
        log.info("[RedisSync] disabled, ignore collect delta publishId={} delta={}", publishId, delta);
    }

    @Override
    public void applyPendingDeltas(List<PublishContent> publishList) {
        // 现在点赞和收藏直接落库，这里不再叠加任何 Redis 增量。
    }

    @Override
    public void syncToDatabaseBySchedule() {
        // 已停用
    }

    @Override
    public void syncToDatabaseOnShutdown() {
        // 已停用
    }
}
