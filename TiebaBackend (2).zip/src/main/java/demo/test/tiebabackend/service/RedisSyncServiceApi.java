package demo.test.tiebabackend.service;

import demo.test.tiebabackend.entity.PublishContent;

import java.util.List;

@SuppressWarnings("unused")
public interface RedisSyncServiceApi {
    // 记录点赞变化
    void recordLikeDelta(Integer publishId, int delta);

    // 记录收藏变化
    void recordCollectDelta(Integer publishId, int delta);

    // 应用待同步的增量到帖子列表
    void applyPendingDeltas(List<PublishContent> publishList);

    // 定时同步到数据库
    void syncToDatabaseBySchedule();

    // 关闭时强制同步到数据库
    void syncToDatabaseOnShutdown();
}


