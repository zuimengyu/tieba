package demo.test.tiebabackend.service;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;

import java.util.List;

public interface UserCollectService {
    // 收藏或取消收藏
    Result<String> collect(Integer userId, Integer publishId);

    // 查询我的收藏列表
    Result<List<PublishContent>> myCollect(Integer userId);

    // 查询当前用户是否收藏当前帖子
    Result<Boolean> collected(Integer userId, Integer publishId);
}

