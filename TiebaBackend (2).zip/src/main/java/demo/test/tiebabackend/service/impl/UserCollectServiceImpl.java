package demo.test.tiebabackend.service.impl;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.mapper.PublishMapper;
import demo.test.tiebabackend.entity.UserCollect;
import demo.test.tiebabackend.mapper.UserCollectMapper;
import demo.test.tiebabackend.service.UserCollectService;
import demo.test.tiebabackend.utils.RedisOps;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.List;

@Service
public class UserCollectServiceImpl implements UserCollectService {

    private static final String PUBLISH_ALL_KEY = "publish:all";

    @Resource
    private UserCollectMapper userCollectMapper;
    @Resource
    private PublishMapper publishMapper;
    @Resource
    private RedisOps redisUtil;
    private static final Logger log = LoggerFactory.getLogger(UserCollectServiceImpl.class);

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<String> collect(Integer userId, Integer publishId) {
        UserCollect collect = userCollectMapper.selectByUserAndPublish(userId, publishId);
        if (collect != null) {
            userCollectMapper.deleteCollect(userId, publishId);
            publishMapper.subCollectCount(publishId);

            // 事务提交后再清理缓存
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    try {
                        invalidatePublishDetailCache(publishId);
                        invalidatePublishListCache();
                    } catch (Exception e) {
                        log.error("[afterCommit] clear collect caches failed publishId={} msg={}", publishId, e.getMessage(), e);
                    }
                }
            });

            return Result.success("取消收藏");
        }

        UserCollect c = new UserCollect();
        c.setUserId(userId);
        c.setPublishId(publishId);
        userCollectMapper.insertCollect(c);
        publishMapper.addCollectCount(publishId);

        // 事务提交后再清理缓存
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                try {
                    invalidatePublishDetailCache(publishId);
                    invalidatePublishListCache();
                } catch (Exception e) {
                    log.error("[afterCommit] clear collect caches failed publishId={} msg={}", publishId, e.getMessage(), e);
                }
            }
        });
        return Result.success("收藏成功");
    }

    @Override
    @Transactional(readOnly = true)
    public Result<List<PublishContent>> myCollect(Integer userId) {
        List<PublishContent> list = userCollectMapper.myCollect(userId);
        return Result.success(list);
    }

    // 查询当前用户是否收藏当前帖子
    @Override
    @Transactional(readOnly = true)
    public Result<Boolean> collected(Integer userId, Integer publishId) {
        UserCollect collect = userCollectMapper.selectByUserAndPublish(userId, publishId);
        return Result.success(collect != null);
    }

    private void invalidatePublishDetailCache(Integer publishId) {
        redisUtil.delete(buildPublishDetailKey(publishId));
    }

    private void invalidatePublishListCache() {
        redisUtil.delete(PUBLISH_ALL_KEY);
    }

    private String buildPublishDetailKey(Integer publishId) {
        return "publish:detail:" + publishId;
    }
}



