package demo.test.tiebabackend.service;

import demo.test.tiebabackend.entity.User;
import demo.test.tiebabackend.Result;
import java.util.Map;

public interface UserService {
    // 登录
    Result<Map<String, Object>> login(String studentId, String password);

    // 注册
    Result<String> register(String studentId, String password);

    // 修改昵称
    Result<String> updateNickname(Integer id, String nickname);

    // 获取当前用户信息
    Result<User> getUserInfo(Integer id);
}