package demo.test.tiebabackend.service.impl;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.User;
import demo.test.tiebabackend.mapper.UserMapper;
import demo.test.tiebabackend.service.UserService;
import demo.test.tiebabackend.utils.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jakarta.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserMapper userMapper;

    // 登录
    @Override
    @Transactional(readOnly = true)
    public Result<Map<String, Object>> login(String studentId, String password) {
        // 1. AES加密学号
        String encryptStu = AESUtil.encrypt(studentId);
        // 2. 查询用户
        User user = userMapper.selectByStudentId(encryptStu);
        if (user == null) {
            return Result.error("账号或密码错误");
        }
        // 3. BCrypt校验密码
        if (!BCryptUtil.check(password, user.getPassword())) {
            return Result.error("账号或密码错误");
        }
        // 4. 解密学号
        user.setStudentId(AESUtil.decrypt(user.getStudentId()));
        //删除返回结果的密码
        user.setPassword(null);
        // 5. 生成JWT
        String token = JWTUtil.createToken(user);

        // 6. 返回结果
        Map<String, Object> map = new HashMap<>();
        map.put("token", token);
        map.put("user", user);
        return Result.success(map);
    }

    // 注册（带事务）
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<String> register(String studentId, String password) {
        // 1. 校验账号是否存在
        String encryptStu = AESUtil.encrypt(studentId);
        User exist = userMapper.selectByStudentId(encryptStu);
        if (exist != null) {
            return Result.error("学号已注册");
        }
        // 2. 封装用户信息
        User user = new User();
        user.setStudentId(encryptStu);
        user.setPassword(BCryptUtil.encrypt(password));
        // 昵称=时间戳
        user.setNickname(System.currentTimeMillis() + "");
        // 3. 插入数据库
        userMapper.insertUser(user);
        return Result.success("注册成功");
    }

    // 修改昵称
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<String> updateNickname(Integer id, String nickname) {
        User user = new User();
        user.setId(id);
        user.setNickname(nickname);
        userMapper.updateNickname(user);
        return Result.success("修改成功");
    }

    // 获取用户信息
    @Override
    @Transactional(readOnly = true)
    public Result<User> getUserInfo(Integer id) {
        User user = userMapper.selectById(id);
        // 解密学号
        user.setStudentId(AESUtil.decrypt(user.getStudentId()));
        user.setPassword(null);
        return Result.success(user);
    }
}