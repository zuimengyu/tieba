package demo.test.tiebabackend.entity;
import lombok.Data;
@Data
public class UserLike {
    private Integer id;
    private Integer userId;
    private Integer publishId;
}