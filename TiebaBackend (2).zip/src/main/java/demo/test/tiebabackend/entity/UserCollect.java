package demo.test.tiebabackend.entity;
import lombok.Data;
@Data
public class UserCollect {
    private Integer id;
    private Integer userId;
    private Integer publishId;
}