package demo.test.tiebabackend.entity;
import lombok.Data;
import java.util.Date;
@Data
public class Comment {
    private Integer id;
    private Integer publishId;
    private Integer userId;
    private String content;
    private Double score;
    private Date createTime;
}