package demo.test.tiebabackend.entity;

import lombok.Data;
import java.util.Date;

@Data
public class User {
    private Integer id;
    // AES加密存储
    private String studentId;
    // BCrypt加密存储
    private String password;
    private String nickname;
}