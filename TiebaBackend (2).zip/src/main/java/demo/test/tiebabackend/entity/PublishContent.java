package demo.test.tiebabackend.entity;
import lombok.Data;
import java.util.Date;
@Data
public class PublishContent {
    private Integer id;
    private Integer userId;
    private String title;
    private String content;
    private Integer likeCount;
    private Integer collectCount;
    private Integer commentCount;
    private Date createTime;
}