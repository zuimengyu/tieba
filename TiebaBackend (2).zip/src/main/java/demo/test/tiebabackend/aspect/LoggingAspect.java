package demo.test.tiebabackend.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("execution(public * demo.test.tiebabackend.service.impl..*(..))")
    public void serviceMethods() {
    }

    @Pointcut("execution(public * demo.test.tiebabackend.utils.RedisUtil.*(..))")
    public void redisMethods() {
    }

    @Around("serviceMethods() || redisMethods()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        Object target = joinPoint.getTarget();
        String category = target == null ? "Unknown" : target.getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        String argsText = Arrays.toString(joinPoint.getArgs());
        log.info("[{}Aop] enter method={} args={}", category, methodName, argsText);
        try {
            Object result = joinPoint.proceed();
            log.info("[{}Aop] exit method={} result={}", category, methodName, result);
            return result;
        } catch (Throwable ex) {
            log.error("[{}Aop] error method={} message={}", category, methodName, ex.getMessage(), ex);
            throw ex;
        }
    }
}

