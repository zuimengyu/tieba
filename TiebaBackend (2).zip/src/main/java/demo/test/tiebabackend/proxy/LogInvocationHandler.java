package demo.test.tiebabackend.proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

public class LogInvocationHandler implements InvocationHandler {

    private static final Logger log = LoggerFactory.getLogger(LogInvocationHandler.class);

    private final Object target;
    private final String category;

    public LogInvocationHandler(Object target, String category) {
        this.target = target;
        this.category = category;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String argText = args == null ? "[]" : Arrays.toString(args);
        log.info("[{}Proxy] enter method={} args={}", category, method.getName(), argText);
        try {
            Object result = method.invoke(target, args);
            log.info("[{}Proxy] exit method={} result={}", category, method.getName(), result);
            return result;
        } catch (InvocationTargetException e) {
            Throwable cause = e.getTargetException();
            log.error("[{}Proxy] error method={} message={}", category, method.getName(), cause == null ? null : cause.getMessage(), cause);
            if (cause != null) {
                throw cause;
            }
            throw e;
        }
    }
}


