package demo.test.tiebabackend.proxy;

import demo.test.tiebabackend.utils.RedisOps;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.core.PriorityOrdered;
import org.jspecify.annotations.NonNull;

import java.lang.reflect.Proxy;

/**
 * 旧版手写动态代理后处理器，已由 Spring AOP 取代。
 * 保留源码仅用于兼容历史代码，不再作为 Spring Bean 参与运行。
 */
public class LoggingProxyPostProcessor implements BeanPostProcessor, PriorityOrdered {

    @Override
    public Object postProcessAfterInitialization(@NonNull Object bean, @NonNull String beanName) throws BeansException {
        Class<?> beanClass = bean.getClass();
        if (Proxy.isProxyClass(beanClass)
                || (!beanClass.getName().startsWith("demo.test.tiebabackend.service.impl") && !(bean instanceof RedisOps))) {
            return bean;
        }

        Class<?>[] interfaces = beanClass.getInterfaces();
        if (interfaces.length == 0) {
            return bean;
        }

        String category = beanClass.getSimpleName();
        return Proxy.newProxyInstance(
                beanClass.getClassLoader(),
                interfaces,
                new LogInvocationHandler(bean, category)
        );
    }


    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }
}


