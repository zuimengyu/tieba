package demo.test.tiebabackend;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> {
    private int code;
    private String msg;
    private T data;

    //操作成功
    public static <T> Result<T> success(T data) {
        return new Result<>(200, "操作成功", data);
    }

    //操作失败
    public static <T> Result<T> error(String msg) {
        return new Result<>(500, msg, null);
    }

    //没登陆
    public static <T> Result<T> unAuth(String msg) {
        return new Result<>(401, msg, null);
    }
}