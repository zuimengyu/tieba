package demo.test.tiebabackend.config;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@MapperScan("demo.test.tiebabackend.mapper")
public class MyBatisConfig {




}