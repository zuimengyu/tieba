package demo.test.tiebabackend.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.utils.JWTUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthTokenInterceptor implements HandlerInterceptor {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // Allow preflight requests to pass through.
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        String token = request.getHeader("token");
        if (token == null || token.trim().isEmpty()) {
            writeJson(response, Result.unAuth("请登录"));
            return false;
        }

        try {
            JWTUtil.getUserId(token);
            return true;
        } catch (Exception e) {
            writeJson(response, Result.unAuth("token无效，请重新登录"));
            return false;
        }
    }

    private void writeJson(HttpServletResponse response, Result<?> result) throws Exception {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write(OBJECT_MAPPER.writeValueAsString(result));
    }
}

