package demo.test.tiebabackend.mapper;

import demo.test.tiebabackend.entity.Comment;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CommentMapper {
    // 根据帖子ID查询评论列表
    @Select("select * from comment where publish_id = #{publishId} order by create_time desc")
    List<Comment> selectByPublishId(Integer publishId);

    // 插入评论
    @Insert("insert into comment(publish_id,user_id,content,score,create_time) values(#{publishId},#{userId},#{content},#{score},#{createTime})")
    int insertComment(Comment comment);

    // 删除某个评论
    @Delete("delete from comment where id = #{id}")
    int deleteById(Integer id);


//    /**
//     * 通过ID查询评论，留作扩展
//     * @param id
//     * @return
//     */
//    @Select("select * from comment where id = #{id}")
//    Comment selectById(Integer id);
}