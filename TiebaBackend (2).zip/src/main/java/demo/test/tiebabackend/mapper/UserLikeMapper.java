package demo.test.tiebabackend.mapper;

import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.entity.UserLike;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserLikeMapper {
    // 查询用户和帖子的点赞关系
    @Select("select * from user_like where user_id = #{userId} and publish_id = #{publishId}")
    UserLike selectByUserAndPublish(Integer userId, Integer publishId);

    // 新增点赞记录
    @Insert("insert into user_like(user_id,publish_id) values(#{userId},#{publishId})")
    int insertLike(UserLike like);

    // 删除点赞记录
    @Delete("delete from user_like where user_id = #{userId} and publish_id = #{publishId}")
    int deleteLike(Integer userId, Integer publishId);

    // 查询我的点赞帖子列表
    @Select("select pc.* from publish_content pc join user_like ul on pc.id = ul.publish_id where ul.user_id = #{userId} order by pc.create_time desc")
    List<PublishContent> myLike(Integer userId);


}