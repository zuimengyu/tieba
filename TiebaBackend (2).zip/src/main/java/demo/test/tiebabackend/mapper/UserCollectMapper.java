package demo.test.tiebabackend.mapper;

import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.entity.UserCollect;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserCollectMapper {
    // 查询用户和帖子的收藏关系
    @Select("select * from user_collect where user_id = #{userId} and publish_id = #{publishId}")
    UserCollect selectByUserAndPublish(Integer userId, Integer publishId);

    // 新增收藏记录
    @Insert("insert into user_collect(user_id,publish_id) values(#{userId},#{publishId})")
    int insertCollect(UserCollect collect);

    // 删除收藏记录
    @Delete("delete from user_collect where user_id = #{userId} and publish_id = #{publishId}")
    int deleteCollect(Integer userId, Integer publishId);

    // 查询我的收藏帖子列表
    @Select("select pc.* from publish_content pc join user_collect uc on pc.id = uc.publish_id where uc.user_id = #{userId} order by pc.create_time desc")
    List<PublishContent> myCollect(Integer userId);


}