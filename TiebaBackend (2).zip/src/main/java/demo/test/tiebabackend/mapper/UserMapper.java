package demo.test.tiebabackend.mapper;

import demo.test.tiebabackend.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
public interface UserMapper {

    // 根据加密学号查询用户
    @Select("select * from user where student_id = #{studentId}")
    User selectByStudentId(String studentId);

    // 注册用户
    @Insert("insert into user(student_id,password,nickname) values(#{studentId},#{password},#{nickname})")
    int insertUser(User user);

    // 修改昵称
    @Update("update user set nickname = #{nickname} where id = #{id}")
    int updateNickname(User user);

    // 根据ID查询用户
    @Select("select * from user where id = #{id}")
    User selectById(Integer id);
}