package demo.test.tiebabackend.mapper;

import demo.test.tiebabackend.entity.PublishContent;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface PublishMapper {

    // 查询所有发布内容，按照发布时间倒序排列
    @Select("select * from publish_content order by create_time desc")
    List<PublishContent> selectAll();

    // 查询当前帖子的详细内容
    @Select("select * from publish_content where id = #{id}")
    PublishContent selectById(Integer id);

    // 发布帖子
    @Insert("insert into publish_content(user_id,title,content,create_time) values(#{userId},#{title},#{content},#{createTime})")
    int insertPublish(PublishContent publish);

    // 增加点赞数
    @Update("update publish_content set like_count = like_count + 1 where id = #{id}")
    int addLikeCount(Integer id);

    // 减少点赞数（防止变为负数）
    @Update("update publish_content set like_count = like_count - 1 where id = #{id} and like_count > 0")
    int subLikeCount(Integer id);

    // 增加收藏数
    @Update("update publish_content set collect_count = collect_count + 1 where id = #{id}")
    int addCollectCount(Integer id);

    // 减少收藏数（防止变为负数）
    @Update("update publish_content set collect_count = collect_count - 1 where id = #{id} and collect_count > 0")
    int subCollectCount(Integer id);

    // 增加评论数
    @Update("update publish_content set comment_count = comment_count + 1 where id = #{id}")
    int addCommentCount(Integer id);

    // 减少评论数（防止变为负数）
    @Update("update publish_content set comment_count = comment_count - 1 where id = #{id} and comment_count > 0")
    int subCommentCount(Integer id);


    // 查询我的发布列表
    @Select("select * from publish_content where user_id = #{userId} order by create_time desc")
    List<PublishContent> myPublish(Integer userId);
}