package demo.test.tiebabackend.controller;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.service.PublishService;
import demo.test.tiebabackend.utils.JWTUtil;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/publish")
public class PublishController {

    @Resource
    private PublishService publishService;

    /**
     * 获取主页的列表
     * @return
     */
    @GetMapping("/list")
    public Result<List<PublishContent>> list(){
        return publishService.getAllPublish();
    }

    /**
     * 发布帖子
     * @param token
     * @param title
     * @param content
     * @return
     */
    @PostMapping("/add")
    public Result<String> add(@RequestHeader("token") String token,
                              String title,String content){
        Integer userId = JWTUtil.getUserId(token);
        return publishService.addPublish(userId,title,content);
    }

    /**
     * 这个帖子的细节
     * @param id
     * @return
     */
    @GetMapping("/detail/{id}")
    public Result<PublishContent> detail(@PathVariable Integer id){
        return publishService.getPublishById(id);
    }

    /**
     * 我的发布
     * @param token
     * @return
     */
    @GetMapping("/my/publish")
    public Result<List<PublishContent>> myPublish(@RequestHeader("token") String token){
        Integer userId = JWTUtil.getUserId(token);
        return publishService.myPublish(userId);
    }

}