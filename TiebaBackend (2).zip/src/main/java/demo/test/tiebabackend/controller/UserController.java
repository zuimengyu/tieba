package demo.test.tiebabackend.controller;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.User;
import demo.test.tiebabackend.service.UserService;
import demo.test.tiebabackend.utils.JWTUtil;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;

    /**
     * 登录
     * @param studentId
     * @param password
     * @return
     */
    @PostMapping("/login")
    public Result<Map<String, Object>> login(String studentId, String password) {
        return userService.login(studentId, password);
    }

    /**
     * 注册
     * @param studentId
     * @param password
     * @return
     */
    @PostMapping("/register")
    public Result<String> register(String studentId, String password) {
        return userService.register(studentId, password);
    }

    /**
     * 获取个人信息
     * @param token
     * @return
     */
    @GetMapping("/info")
    public Result<User> info(@RequestHeader String token) {
        Integer id = JWTUtil.getUserId(token);
        return userService.getUserInfo(id);
    }

    /**
     * 修改昵称
     * @param token
     * @param nickname
     * @return
     */
    @PostMapping("/updateNick")
    public Result<String> updateNick(@RequestHeader String token, String nickname) {
        Integer id = JWTUtil.getUserId(token);
        return userService.updateNickname(id, nickname);
    }
}