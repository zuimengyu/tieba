package demo.test.tiebabackend.controller;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.service.UserLikeService;
import demo.test.tiebabackend.utils.JWTUtil;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/like")
public class LikeController {

    @Resource
    private UserLikeService userLikeService;

    /**
     * like反转
     * @param token
     * @param publishId
     * @return
     */
    @PostMapping("/toggle")
    public Result<String> toggle(@RequestHeader("token") String token, Integer publishId) {
        Integer userId = JWTUtil.getUserId(token);
        return userLikeService.like(userId, publishId);
    }

    /**
     * 我的like
     * @param token
     * @return
     */
    @GetMapping("/my")
    public Result<List<PublishContent>> myLike(@RequestHeader("token") String token) {
        Integer userId = JWTUtil.getUserId(token);
        return userLikeService.myLike(userId);
    }

    /**
     * 查询当前用户是否点赞当前帖子
     * @param token token
     * @param publishId 帖子ID
     * @return 是否点赞
     */
    @GetMapping("/status")
    public Result<Boolean> liked(@RequestHeader("token") String token, Integer publishId) {
        Integer userId = JWTUtil.getUserId(token);
        return userLikeService.liked(userId, publishId);
    }
}

