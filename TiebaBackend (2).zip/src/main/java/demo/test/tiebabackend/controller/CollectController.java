package demo.test.tiebabackend.controller;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.PublishContent;
import demo.test.tiebabackend.service.UserCollectService;
import demo.test.tiebabackend.utils.JWTUtil;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/collect")
public class CollectController {

    @Resource
    private UserCollectService userCollectService;

    /**
     * 收藏反转
     * @param token
     * @param publishId
     * @return
     */
    @PostMapping("/toggle")
    public Result<String> toggle(@RequestHeader("token") String token, Integer publishId) {
        Integer userId = JWTUtil.getUserId(token);
        return userCollectService.collect(userId, publishId);
    }

    /**
     * 我的收藏
     * @param token
     * @return
     */
    @GetMapping("/my")
    public Result<List<PublishContent>> myCollect(@RequestHeader("token") String token) {
        Integer userId = JWTUtil.getUserId(token);
        return userCollectService.myCollect(userId);
    }

    /**
     * 查询当前用户是否收藏当前帖子
     * @param token token
     * @param publishId 帖子ID
     * @return 是否收藏
     */
    @GetMapping("/status")
    public Result<Boolean> collected(@RequestHeader("token") String token, Integer publishId) {
        Integer userId = JWTUtil.getUserId(token);
        return userCollectService.collected(userId, publishId);
    }
}

