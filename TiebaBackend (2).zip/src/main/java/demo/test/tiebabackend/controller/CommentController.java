package demo.test.tiebabackend.controller;

import demo.test.tiebabackend.Result;
import demo.test.tiebabackend.entity.Comment;
import demo.test.tiebabackend.service.CommentService;
import demo.test.tiebabackend.utils.JWTUtil;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/comment")
public class CommentController {

    @Resource
    private CommentService commentService;


    /**
     * 根据帖子id获取评论列表
     * @param publishId
     * @return
     */
    @GetMapping("/list/{publishId}")
    public Result<List<Comment>> list(@PathVariable Integer publishId){
        return commentService.getByPublishId(publishId);
    }

    /**
     * 添加评论
     * @param token
     * @param publishId
     * @param content
     * @param score
     * @return
     */
    @PostMapping("/add")
    public Result<String> add(@RequestHeader("token") String token,
                              Integer publishId,String content,Double score){
        Integer userId = JWTUtil.getUserId(token);
        return commentService.addComment(userId,publishId,content,score);
    }
}