# TiebaBackend API 文档

## 1. 基础信息

- Base URL: `http://127.0.0.1:8080`
- PowerShell 示例建议先定义：`$BASE="http://127.0.0.1:8080"`
- 请求参数格式: `application/x-www-form-urlencoded`（当前控制器参数都不是 `@RequestBody`）
- 鉴权 Header: `token: <JWT_TOKEN>`
- 返回体统一结构:

```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {}
}
```

`code` 含义：
- `200`: 成功
- `500`: 失败（例如 `没有token`、`token无效`、业务错误）
- `401`: 代码中有定义，但当前拦截器默认返回 500 文本错误

## 2. 鉴权规则

根据 `WebMvcConfig` 与 `AuthTokenInterceptor`：

- 不需要 token:
  - `POST /user/login`
  - `POST /user/register`
- 其余接口都需要 token
- 缺少 token 返回:

```json
{"code":500,"msg":"没有token","data":null}
```

- token 无效返回:

```json
{"code":500,"msg":"token无效","data":null}
```

---

## 3. 用户模块 `/user`

### 3.1 注册
- **POST** `/user/register`
- **是否鉴权**: 否
- **参数**:
  - `studentId` (string)
  - `password` (string)
- **示例**:

```bash
curl -X POST "http://127.0.0.1:8080/user/register" \
  -d "studentId=20240003" \
  -d "password=123456"
```

- **成功响应示例**:

```json
{"code":200,"msg":"操作成功","data":"注册成功"}
```

### 3.2 登录
- **POST** `/user/login`
- **是否鉴权**: 否
- **参数**:
  - `studentId` (string)
  - `password` (string)
- **示例**:

```bash
curl -X POST "http://127.0.0.1:8080/user/login" \
  -d "studentId=20240001" \
  -d "password=123456"
```

- **成功响应示例**:

```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "user": {
      "id": 2,
      "nickname": "1777111598173",
      "password": null,
      "studentId": "20240001"
    },
    "token": "<JWT_TOKEN>"
  }
}
```

### 3.3 获取用户信息
- **GET** `/user/info`
- **是否鉴权**: 是
- **Header**: `token`
- **示例**:

```bash
curl -X GET "http://127.0.0.1:8080/user/info" \
  -H "token:<JWT_TOKEN>"
```

### 3.4 修改昵称
- **POST** `/user/updateNick`
- **是否鉴权**: 是
- **Header**: `token`
- **参数**:
  - `nickname` (string)
- **示例**:

```bash
curl -X POST "http://127.0.0.1:8080/user/updateNick" \
  -H "token:<JWT_TOKEN>" \
  -d "nickname=nick_test_001"
```

---

## 4. 帖子模块 `/publish`

### 4.1 帖子列表
- **GET** `/publish/list`
- **是否鉴权**: 是
- **Header**: `token`
- **示例**:

```bash
curl -X GET "http://127.0.0.1:8080/publish/list" \
  -H "token:<JWT_TOKEN>"
```

- **返回 data**: `PublishContent[]`

### 4.2 发布帖子
- **POST** `/publish/add`
- **是否鉴权**: 是
- **Header**: `token`
- **参数**:
  - `title` (string)
  - `content` (string)
- **示例**:

```bash
curl -X POST "http://127.0.0.1:8080/publish/add" \
  -H "token:<JWT_TOKEN>" \
  -d "title=测试帖子标题" \
  -d "content=测试帖子内容"
```

### 4.3 帖子详情
- **GET** `/publish/detail/{id}`
- **是否鉴权**: 是
- **Header**: `token`
- **路径参数**:
  - `id` (int)
- **示例**:

```bash
curl -X GET "http://127.0.0.1:8080/publish/detail/1" \
  -H "token:<JWT_TOKEN>"
```

### 4.4 点赞/取消点赞（切换）
- **POST** `/like/toggle`
- **是否鉴权**: 是
- **Header**: `token`
- **参数**:
  - `publishId` (int)
- **说明**:
  - 已点赞 -> 取消点赞
  - 未点赞 -> 点赞
- **示例**:

```bash
curl -X POST "http://127.0.0.1:8080/like/toggle" \
  -H "token:<JWT_TOKEN>" \
  -d "publishId=1"
```

### 4.5 收藏/取消收藏（切换）
- **POST** `/collect/toggle`
- **是否鉴权**: 是
- **Header**: `token`
- **参数**:
  - `publishId` (int)
- **说明**:
  - 已收藏 -> 取消收藏
  - 未收藏 -> 收藏
- **示例**:

```bash
curl -X POST "http://127.0.0.1:8080/collect/toggle" \
  -H "token:<JWT_TOKEN>" \
  -d "publishId=1"
```

### 4.6 我的发布
- **GET** `/publish/my/publish`
- **是否鉴权**: 是
- **Header**: `token`

```bash
curl -X GET "http://127.0.0.1:8080/publish/my/publish" \
  -H "token:<JWT_TOKEN>"
```

### 4.7 我的点赞
- **GET** `/like/my`
- **是否鉴权**: 是
- **Header**: `token`

```bash
curl -X GET "http://127.0.0.1:8080/like/my" \
  -H "token:<JWT_TOKEN>"
```

### 4.8 我的收藏
- **GET** `/collect/my`
- **是否鉴权**: 是
- **Header**: `token`

```bash
curl -X GET "http://127.0.0.1:8080/collect/my" \
  -H "token:<JWT_TOKEN>"
```

### 4.9 当前用户是否已点赞当前帖子
- **GET** `/like/status`
- **是否鉴权**: 是
- **Header**: `token`
- **参数**:
  - `publishId` (int)

```bash
curl -X GET "http://127.0.0.1:8080/like/status?publishId=1" \
  -H "token:<JWT_TOKEN>"
```

- **成功响应示例**:

```json
{"code":200,"msg":"操作成功","data":true}
```

### 4.10 当前用户是否已收藏当前帖子
- **GET** `/collect/status`
- **是否鉴权**: 是
- **Header**: `token`
- **参数**:
  - `publishId` (int)

```bash
curl -X GET "http://127.0.0.1:8080/collect/status?publishId=1" \
  -H "token:<JWT_TOKEN>"
```

- **成功响应示例**:

```json
{"code":200,"msg":"操作成功","data":false}
```

---

## 5. 评论模块 `/comment`

### 5.1 评论列表
- **GET** `/comment/list/{publishId}`
- **是否鉴权**: 是
- **Header**: `token`
- **路径参数**:
  - `publishId` (int)

```bash
curl -X GET "http://127.0.0.1:8080/comment/list/1" \
  -H "token:<JWT_TOKEN>"
```

- **返回 data**: `Comment[]`

### 5.2 发表评论
- **POST** `/comment/add`
- **是否鉴权**: 是
- **Header**: `token`
- **参数**:
  - `publishId` (int)
  - `content` (string)
  - `score` (double)

```bash
curl -X POST "http://127.0.0.1:8080/comment/add" \
  -H "token:<JWT_TOKEN>" \
  -d "publishId=1" \
  -d "content=这是一条测试评论" \
  -d "score=4.5"
```

---

## 6. 实体字段说明

### 6.1 `PublishContent`
- `id` int
- `userId` int
- `title` string
- `content` string
- `likeCount` int
- `collectCount` int
- `commentCount` int
- `createTime` date

### 6.2 `Comment`
- `id` int
- `publishId` int
- `userId` int
- `content` string
- `score` double
- `createTime` date

### 6.3 `User`
- `id` int
- `studentId` string（返回前已解密）
- `password` string/null（登录返回和 info 中通常为 null）
- `nickname` string

---

## 7. 当前版本注意事项

1. 所有接口参数目前是表单参数，未使用 JSON body。
2. 除登录/注册外都需要 `token` header。
3. 如果命令行出现中文乱码（如 `鎿嶄綔鎴愬姛`），通常是终端编码问题，不影响接口实际逻辑。
4. 建议后续补上数据库外键和业务层帖子存在性校验，避免“不存在帖子仍可被操作”的脏数据。
5. 历史路径 `/publish/like`、`/publish/collect`、`/publish/my/like`、`/publish/my/collect` 已废弃，当前请使用 `/like/*` 与 `/collect/*`。

